﻿using System;

namespace EFUnitOfWork.UploadUtil
{
    public struct SortedFile
    {
        public int FileOrder { get; set; }
        public String FileName { get; set; }
    }
}