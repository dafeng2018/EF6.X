﻿namespace DDD.Sample.Domain
{
    public interface IAggregateRoot
    {
        int Id { get; }
    }
}
