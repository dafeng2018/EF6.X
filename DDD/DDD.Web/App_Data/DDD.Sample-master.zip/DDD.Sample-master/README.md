# DDD.Sample

详细介绍：

* [DDD 领域驱动设计－谈谈 Repository、IUnitOfWork 和 IDbContext（1） 的实践](http://www.cnblogs.com/xishuai/p/ddd-repository-iunitofwork-and-idbcontext.html)
* [DDD 领域驱动设计－谈谈 Repository、IUnitOfWork 和 IDbContext（2） 的实践](http://www.cnblogs.com/xishuai/p/ddd-repository-iunitofwork-and-idbcontext-part-2.html)
* [DDD 领域驱动设计－谈谈 Repository、IUnitOfWork 和 IDbContext（3） 的实践](http://www.cnblogs.com/xishuai/p/ddd-repository-iunitofwork-and-idbcontext-part-3.html)
